/******
 Name: Bryce Dunlap
 Assignment: Lab 4
 Date: 3/14/2024
 ******/


public class Node {
    // this class is responsible for saying, hey theres a
    // todo list in each node and pointer to each node.

    public Task todoData;
    public Node next;

}

