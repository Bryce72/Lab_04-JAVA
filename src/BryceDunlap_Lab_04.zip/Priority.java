/******
 Name: Bryce Dunlap
 Assignment: Lab 4
 Date: 3/14/2024
 ******/

public enum Priority {
    LOW,
    KINDA_IMPORTANT,
    URGENT
}
